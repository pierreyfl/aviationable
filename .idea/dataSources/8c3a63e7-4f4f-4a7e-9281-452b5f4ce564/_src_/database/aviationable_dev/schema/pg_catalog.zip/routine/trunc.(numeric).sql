CREATE FUNCTION trunc (numeric) RETURNS numeric
	LANGUAGE sql
AS $$
select pg_catalog.trunc($1,0)
$$
